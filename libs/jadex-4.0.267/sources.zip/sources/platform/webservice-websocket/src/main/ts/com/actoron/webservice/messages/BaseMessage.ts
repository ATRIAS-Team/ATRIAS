export class ServiceMessage 
{
    public callid:string;

    constructor(public __classname:string) 
    {
    }
}
