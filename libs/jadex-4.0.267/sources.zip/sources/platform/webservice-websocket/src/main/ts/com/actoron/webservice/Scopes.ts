export class Scopes 
{
//	/** None component scope (nothing will be searched). */
//	const SCOPE_NONE = "none";
//
//	/** Local component scope. */
//	const SCOPE_LOCAL = "local";
//
//	/** Component scope. */
//	const SCOPE_COMPONENT = "component";
//
//	/** Application scope. */
//	const SCOPE_APPLICATION = "application";

    /** Platform scope. */
    public static SCOPE_PLATFORM:string = "platform";

    /** Global scope. */
    public static SCOPE_GLOBAL:string = "global";

//	/** Parent scope. */
//	SCOPE_PARENT:string = "parent";

    /** Session scope. */
    public static SCOPE_SESSION:string = "session";
}