package jadex.tools.filetransfer;

public class TransferHandler
{

}
