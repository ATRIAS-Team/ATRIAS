package jadex.bpmn.testcases;

import jadex.commons.future.IFuture;

/**
 * 
 */
public interface IAService 
{
	/**
	 *  Test method.
	 */
	public IFuture<String> test();
}
